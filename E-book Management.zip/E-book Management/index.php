<html lang="en">
<?php
    if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location: http://localhost/E-book Management/user-login.php');
    exit;
  }
 ?>
 <?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<title>E-Book Management</title>
<head>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width-device-width, intial-scale=1.0">
	  <link rel="stylesheet" href="./css/style.css">
	  <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	  <script src="./js/jquery.js"></script>
</head>
<body>
	<div class="top-header">
		<span><h3>E-BOOK MANAGEMENT</h3></span>
	</div>

 	<div class="nav">
 		<ul>
 			<li><a href="index.php">Dashboard</a></li>
 			<li><a href="books.php">Default Books</a></li>
            <li><a href="http://localhost/E-book Management/download.php">Recently Uploaded</a></li>
              <li><a href="http://localhost/E-book%20Management/Book-Finder/index.php" target="_self">Search Books</a></li>
               <li><a href="http://localhost/E-book%20Management/my-profile.php" target="_self">My profile</a></li>
            <li><a href="user-login.php">Logoout</a></li>
      		
 		</ul>
 	</div>
 	 <div class="slider">
 	 	<img src="./image/logo.jpg" class="slider-image" alt="image">
 	 </div>
 	 <div class="main">
 	 	<span>About Us</span>
 	 	<p>An ebook (short for electronic book), also known as an e-book or eBook, is a book publication made available in digital form, consisting of text, images, or both, readable on the flat-panel display of computers or other electronic devices.[1] Although sometimes defined as "an electronic version of a printed book",[2] some e-books exist without a printed equivalent. E-books can be read on dedicated e-reader devices, but also on any computer device that features a controllable viewing screen, including desktop computers, laptops, tablets and smartphones.</p>
 	 </div>

 	 <div class="footer">
 	 	<div class="footer-contact">
 	 		<span>Designed by:</span>
 	 		<p>Charan</p>
 	 	</div>
 	 	<div class="footter-info">
 	 		<span>Visit</span>
 	 		<a href="http://localhost/online-shopping/index.php" target="_blank">Shopping Management Model</a>
 	 		<a href="http://localhost/result-management/index.php" target="_blank">Result Management model</a>
 	 	</div>
		</div>
 </body>
 </html>

