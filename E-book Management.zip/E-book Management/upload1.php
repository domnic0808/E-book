<?php
 
// Getting uploaded file
$file = $_FILES["file"];
 
// Uploading in "uplaods" folder
move_uploaded_file($file["tmp_name"], "upload1/" . $file["name"]);
 
// Redirecting back
header("Location: http://localhost/E-book Management/dash1.php ");