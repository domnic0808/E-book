<html lang="en">
<title>Library Management</title>
<head>
      <meta charset="utf-8">
      <meta name="viewport" content="width-device-width, intial-scale=1.0">
      <link rel="stylesheet" href="./css/style.css">
      <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
   <script src="./js/jquery.js"></script>
    </head>
<div class="top-header">
   <span><h3>E-BOOK MANAGEMENT</h3></span>
     </div>
 	
 	<div class="nav">
 		<ul>
 			<li><a href="index.php">Dashboard</a></li>
 			<li><a href="books.php">Default Books</a></li>
            <li><a href="http://localhost/E-book Management/download.php">Recently Uploaded</a></li>
            <li><a href="http://localhost/E-book%20Management/Book-Finder/index.php" target="_self">Search Books</a></li>
            <li><a href="http://localhost/E-book%20Management/my-profile.php" target="_self">My profile</a></li>
             <li><a href="user-login.php">Logoout</a></li>
             
      	
 		</ul>
 	</div>
    </html>