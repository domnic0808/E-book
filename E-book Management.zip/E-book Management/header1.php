<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>E Book MANAGEMENT | User Dash Board</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<style>
.dropbtn {
  background-color: #f7f7f7;;
  color: black;
  padding: 19px;
  font-size: 16px;
 border-bottom:0px solid #9170E4;;
 width: 100%;
}

.dropdown {
  position: relative;
  display: inline;
}

.dropdown-content {
  display: none ;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 200px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 10px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>
<div class="navbar navbar-inverse set-radius-zero" >
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand">

                    <img src="assets/img/2.jpg" style="height: 90px; width: 100px;">
                </a>

            </div>

            <div class="right-div">
                <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
            </div>
        </div>
    </div>
    <!-- LOGO HEADER END-->
    <section class="menu-section">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-left">
                            <li><a href="self.php" class="menu-top-active">DASHBOARD</a></li>
                             <li><a href ="dashboard.php" class="menu-top-active">UPLOAD NOVELS</a></li>
                              <li><a href ="dash1.php" class="menu-top-active">UPLOAD BOOKS</a></li>
                                <li>
                                <div class="dropdown">
                                <button class="dropbtn">Author<i class="fa fa-angle-down"></i></a></button>
                                <div class="dropdown-content">
                                  <a href="add-author.php">Add Author</a>
                                 <a href="manage-authors.php">Manage Author</a>
    
                                  </div>
                                </div>
                            </li>
                            <li>
                              <div class="dropdown">
                                <button class="dropbtn">Book<i class="fa fa-angle-down"></i></a></button>
                                <div class="dropdown-content">
                                  <a href="add-book.php">Add Book</a>
                                 <a href="manage-books.php">Manage Book</a>
                                </div>
                                </div>
                            </li>  
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>