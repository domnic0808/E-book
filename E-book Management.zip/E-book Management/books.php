<html lang="en">
<title>Library Management</title>
<head>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width-device-width, intial-scale=1.0">
	  <link rel="stylesheet" href="./css/style.css">
	  <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
   <script src="./js/jquery.js"></script>
    </head>
<style>
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
<body>
	<div class="top-header">
   <span><h3>E-BOOK MANAGEMENT</h3></span>
     </div>
 	
 	<div class="nav">
 		<ul>
 			<li><a href="index.php">Dashboard</a></li>
 			<li><a href="books.php">Default Books</a></li>
            <li><a href="http://localhost/E-book Management/download.php">Recently Uploaded</a></li>
            <li><a href="http://localhost/E-book%20Management/Book-Finder/index.php" target="_self">Search Books</a></li>
            <li><a href="http://localhost/E-book%20Management/my-profile.php" target="_self">My profile</a></li>
             <li><a href="user-login.php">Logoout</a></li>
             
      	
 		</ul>
 	</div>
</div class="container-fluid">
  <h3 style="text-align: center; margin: 2px; font-family: sans-serif; font-size: 26px; text-decoration: underline; "><mark style="color: red;">TOP NOVELS</mark></h3>
 	<div class="gallery">
  <a target="_blank" href="./book/ponniyin-selvan.pdf">
    <img src="./image/ps.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">PONNIYIN SELVAN</div>
</div>

<div class="gallery">
  <a target="_blank" href="./book/the-great-gatsby.pdf">
    <img src="./image/great.jpg" alt="Forest" width="600" height="420">
  </a>
  <div class="desc"><br>The Great Gatsby</div>
</div>

<div class="gallery">
  <a target="_blank" href="./book/lord of rings.pdf">
    <img src="./image/LS.jpg" alt="Northern Lights" width="600" height="400">
  </a>
  <div class="desc">The Lord Of Rings</div>
</div>

<div class="gallery">
  <a target="_blank" href="./book/war-and-peace.pdf">
    <img src="./image/W&P.jpg" alt="Mountains" width="600" height="400">
  </a>
  <div class="desc">WAR AND PEACE</div>
</div>

<div class="gallery">
  <a target="_blank" href="./book/invisible man.pdf">
    <img src="./image/Inv.jpg" alt="Mountains" width="600" height="380">
  </a>
  <div class="desc">the invisible man</div>
</div>

<div class="gallery">
  <a target="_blank" href="./book/Mockingbird.pdf">
    <img src="./image/KM.jpg" alt="Mountains" width="600" height="400">
  </a>
  <div class="desc">Kill a Mockingbird</div>
</div>
<div class="gallery">
  <a target="_blank" href="./book/jane eyre.pdf">
    <img src="./image/j.jpg" alt="Mountains" width="600" height="400">
  </a>
  <div class="desc">Jane Eyre</div>
</div>
</body>
</html>
