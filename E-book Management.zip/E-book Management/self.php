<html>
 <?php
    if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location: http://localhost/E-book Management/admin.php');
    exit;
  }
 ?>
  <title>ADMIN DASHBOARD</title>
 <head>
  <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
  </head>
  <body>
      <?php include 'header1.php' ?>
      <h2 style="text-align: center; padding: 10px 10px; font-family: fantasy; text-decoration: underline; ">ADMIN DASHBOARD</h2>
      <h3 style="display: inline-block; font-family: sans-serif; text-orientation: use-glyph-orientation;"><b>uploaded Novels:</b></h3>
      <?php
   $files = scandir("uploads");
   for ($a = 2; $a < count($files); $a++) {
   	?>
    <p>
   	<center><a download="<?php echo $files[$a] ?>" href="uploads/<?php echo $files[$a] ?>"><?php echo $files[$a] ?></a> &nbsp;&nbsp;	<a href =".\uploads\invisible man.pdf" target="_blank">Click TO VIEW</a></center></p>
    <?php
  }
  
   

  