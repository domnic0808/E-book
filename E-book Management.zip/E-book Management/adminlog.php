<?php

$username="Admin";
$password="admin@123";

$inputname=$_POST['username'];
$inputpwd=$_POST['password'];

if(($username==$inputname) && ($password==$inputpwd))
 header("Location: http://localhost/E-book Management/self.php");
else 
 echo "<script>alert('Invalid Credinails');
 window.location.href='http://localhost/E-book Management/admin.php';</script>";
?>
