<html>
 <?php
    if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location: http://localhost/E-book%20Management/admin.php');
    exit;
  }
 ?>
 <?php include 'header1.php'; ?>

<style>
body{ 
       font-size: 16px;
       font-family: 'Roboto', sans-serif;
       background-color: white;
       color: black;
       margin: 0;
}
h2
{
    text-align: center;
    font-size: 42px;

}
input[type=submit]{
 
}
input[type=submit]:hover{
    background-color: #008CBA;
  color: white;
}
a:link {
  color: green;

}
a:hover {
  color: darkred;
}

</style>

</div>
<body>
  <br>
    <form method="POST" action="upload1.php" enctype="multipart/form-data">
    <center><input type="file" name="file">  <input type="submit" value="Upload"></center>
  </form>
  <div>
    <a href="#"><h3  style="text-align: center;"><mark>UPLOADED BOOKS</mark></h3></a>
</div>
  <?php
   $files = scandir("upload1");
   for ($a = 2; $a < count($files); $a++) {
    ?>
    <p>
    <center><a download="<?php echo $files[$a] ?>" href="uploads/<?php echo $files[$a] ?>"><?php echo $files[$a] ?></a></center>
    </p>
    <?php
   }

   