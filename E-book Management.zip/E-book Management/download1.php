<html>
<head>
      <meta charset="utf-8">
      <meta name="viewport" content="width-device-width, intial-scale=1.0">
      <link rel="stylesheet" href="./css/style.css">
      <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
      <script src="./js/jquery.js"></script>
</head>
<style>
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
<body>
    <div class="top-header">
        <span><h3>E-BOOK MANAGEMENT</h3></span>
    </div>
    
    <div class="nav">
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="books.php">Default Books</a></li>
            <li><a href="download.php">Recently Uploaded</a></li>
             <li><a href="user-login.php">Logoout</a></li>
         
        </ul>
    </div>
<div>
    <h2 style="text-align: center; "><mark style="background-color: yellow;">RECENTLY UPLODED BOOKS</mark></h2>
    <?php
 
// This will return all files in that folder
$files = scandir("upload1");
 
// If you are using windows, first 2 indexes are "." and "..",
// if you are using Mac, you may need to start the loop from 3,
// because the 3rd index in Mac is ".DS_Store" (auto-generated file by Mac)
for ($a = 2; $a < count($files); $a++)
{
    ?>
    <p style="text-align: center;">
        <!-- Displaying file name !-->
        <?php echo $files[$a]; ?>
 
        <!-- href should be complete file path !-->
        <!-- download attribute should be the name after it downloads !-->
        <a href="upload1/<?php echo $files[$a]; ?>" download="<?php echo $files[$a]; ?>">
            Download
        </a>
    </p>
    <?php
}
?>
</html>